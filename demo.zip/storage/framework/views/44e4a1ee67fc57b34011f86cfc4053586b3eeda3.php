<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <title>Document</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div style="text-align: center; margin: 100px 200px;" class="container">
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div style="display: flex; flex-flow: row;">
            <div class="category">
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" id="category<?php echo e($category->id); ?>"
                           value="<?php echo e($category->id); ?>">
                    <label class="form-check-label" for="category<?php echo e($category->id); ?>"><?php echo e($category->name); ?></label>
                </div>
            </div>
            <div style="display: flex; flex-flow: row;" class="form-box">
                <?php $__currentLoopData = $category->forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="checkbox" id="form<?php echo e($formData->id); ?>" value="<?php echo e($formData->id); ?>">
                        <label class="form-check-label" for="form<?php echo e($formData->id); ?>"><?php echo e($formData->value); ?></label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</body>
</html><?php /**PATH /Users/Mahfuz/Project/Personal/laravel-learning/resources/views/display.blade.php ENDPATH**/ ?>